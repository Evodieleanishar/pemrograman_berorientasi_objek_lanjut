<?php
require_once 'database.php';
class Material 
{
    private $db;
    private $table = 'material';
    public $kodematerial = "";
    public $namamaterial = "";
    public $stock = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_kodematerial(int $kodematerial)
    {
        $query = "SELECT * FROM $this->table WHERE kodematerial = $kodematerial";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kodematerial`,`namamaterial`,`stock`) VALUES ('$this->kodematerial','$this->namamaterial','$this->stock')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET kodematerial = '$this->kodematerial', namamaterial = '$this->namamaterial', stock = '$this->stock' 
        WHERE idmaterial = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_kodematerial($kodematerial): int
    {
        $query = "UPDATE $this->table SET kodematerial = '$this->kodematerial', namamaterial = '$this->namamaterial', stock = '$this->stock' 
        WHERE kodematerial = $kodematerial";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE idmaterial = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_kodematerial($kodematerial): int
    {
        $query = "DELETE FROM $this->table WHERE kodematerial = $kodematerial";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>
