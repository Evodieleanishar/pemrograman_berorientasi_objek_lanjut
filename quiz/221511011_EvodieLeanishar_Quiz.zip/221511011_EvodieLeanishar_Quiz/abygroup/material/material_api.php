<?php
require_once 'database.php';
require_once 'Material.php';
$db = new MySQLDatabase();
$material = new Material($db);
$id=0;
$kodematerial=0;
// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];
// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodematerial'])){
            $kodematerial = $_GET['kodematerial'];
        }
        if($id>0){    
            $result = $material->get_by_id($id);
        }elseif($kodematerial>0){
            $result = $material->get_by_kodematerial($kodematerial);
        } else {
            $result = $material->get_all();
        }        
       
        $val = array();
        while ($row = $result->fetch_assoc()) {
            $val[] = $row;
        }
        
        header('Content-Type: application/json');
        echo json_encode($val);
        break;
    
    case 'POST':
        // Add a new material
        $material->kodematerial = $_POST['kodematerial'];
        $material->namamaterial = $_POST['namamaterial'];
        $material->stock = $_POST['stock'];
       
        $material->insert();
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Material created successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Material not created.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'PUT':
        // Update an existing data
        $_PUT = [];
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodematerial'])){
            $kodematerial = $_GET['kodematerial'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $material->kodematerial = $_PUT['kodematerial'];
        $material->namamaterial = $_PUT['namamaterial'];
        $material->stock = $_PUT['stock'];
        if($id>0){    
            $material->update($id);
        }elseif($kodematerial<>""){
            $material->update_by_kodematerial($kodematerial);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Material updated successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Material update failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'DELETE':
        // Delete a user
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodematerial'])){
            $kodematerial = $_GET['kodematerial'];
        }
        if($id>0){    
            $material->delete($id);
        }elseif($kodematerial>0){
            $material->delete_by_kodematerial($kodematerial);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Material deleted successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Material delete failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
    }
$db->close()
?>
