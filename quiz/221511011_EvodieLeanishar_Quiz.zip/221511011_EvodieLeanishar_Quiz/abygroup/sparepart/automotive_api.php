<?php
require_once 'database.php';
require_once 'Automotive.php';
$db = new MySQLDatabase();
$automotive = new Automotive($db);
$id=0;
$kodesparepart=0;
// Check the HTTP request method
$method = $_SERVER['REQUEST_METHOD'];
// Handle the different HTTP methods
switch ($method) {
    case 'GET':
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodesparepart'])){
            $kodesparepart = $_GET['kodesparepart'];
        }
        if($id>0){    
            $result = $automotive->get_by_id($id);
        }elseif($kodesparepart>0){
            $result = $automotive->get_by_kodesparepart($kodesparepart);
        } else {
            $result = $automotive->get_all();
        }        
       
        $val = array();
        while ($row = $result->fetch_assoc()) {
            $val[] = $row;
        }
        
        header('Content-Type: application/json');
        echo json_encode($val);
        break;
    
    case 'POST':
        // Add a new automotive
        $automotive->kodesparepart = $_POST['kodesparepart'];
        $automotive->namasparepart = $_POST['namasparepart'];
        $automotive->stock = $_POST['stock'];
       
        $automotive->insert();
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Automotive created successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Automotive not created.';
        }
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'PUT':
        // Update an existing data
        $_PUT = [];
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodesparepart'])){
            $kodesparepart = $_GET['kodesparepart'];
        }
        parse_str(file_get_contents("php://input"), $_PUT);
        $automotive->kodesparepart = $_PUT['kodesparepart'];
        $automotive->namasparepart = $_PUT['namasparepart'];
        $automotive->stock = $_PUT['stock'];
        if($id>0){    
            $automotive->update($id);
        }elseif($kodesparepart<>""){
            $automotive->update_by_kodesparepart($kodesparepart);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Automotive updated successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Automotive update failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    case 'DELETE':
        // Delete a user
        if(isset($_GET['id'])){
            $id = $_GET['id'];
        }
        if(isset($_GET['kodesparepart'])){
            $kodesparepart = $_GET['kodesparepart'];
        }
        if($id>0){    
            $automotive->delete($id);
        }elseif($kodesparepart>0){
            $automotive->delete_by_kodesparepart($kodesparepart);
        } else {
            
        } 
        
        $a = $db->affected_rows();
        if($a>0){
            $data['status']='success';
            $data['message']='Data Automotive deleted successfully.';
        } else {
            $data['status']='failed';
            $data['message']='Data Automotive delete failed.';
        }        
        header('Content-Type: application/json');
        echo json_encode($data);
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
    }
$db->close()
?>
