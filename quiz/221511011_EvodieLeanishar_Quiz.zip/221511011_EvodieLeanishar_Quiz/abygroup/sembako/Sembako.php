<?php
require_once 'database.php';
class Sembako 
{
    private $db;
    private $table = 'sembako';
    public $kodebarang = "";
    public $namabarang = "";
    public $stock = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_kodebarang(int $kodebarang)
    {
        $query = "SELECT * FROM $this->table WHERE kodebarang = $kodebarang";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kodebarang`,`namabarang`,`stock`) VALUES ('$this->kodebarang','$this->namabarang','$this->stock')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET kodebarang = '$this->kodebarang', namabarang = '$this->namabarang', stock = '$this->stock' 
        WHERE idbarang = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_kodebarang($kodebarang): int
    {
        $query = "UPDATE $this->table SET kodebarang = '$this->kodebarang', namabarang = '$this->namabarang', stock = '$this->stock' 
        WHERE kodebarang = $kodebarang";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE idbarang = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_kodebarang($kodebarang): int
    {
        $query = "DELETE FROM $this->table WHERE kodebarang = $kodebarang";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>
