import requests
import json
class Material:
    def __init__(self):
        self.__id=None
        self.__kodematerial = None
        self.__namamaterial = None
        self.__stock = None
        self.__url = "http://f0834912.xsph.ru/abygroup/material/material_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kodematerial(self):
        return self.__kodematerial
        
    @kodematerial.setter
    def kodematerial(self, value):
        self.__kodematerial = value
    @property
    def namamaterial(self):
        return self.__namamaterial
        
    @namamaterial.setter
    def namamaterial(self, value):
        self.__namamaterial = value
    @property
    def stock(self):
        return self.__stock
        
    @stock.setter
    def stock(self, value):
        self.__stock = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kodematerial(self, kodematerial):
        url = self.__url+"?kodematerial="+kodematerial
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['idmaterial']
            self.__kodematerial = item['kodematerial']
            self.__namamaterial = item['namamaterial']
            self.__stock = item['stock']
        return data
    def simpan(self):
        payload = {
            "kodematerial":self.__kodematerial,
            "namamaterial":self.__namamaterial,
            "stock":self.__stock
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kodematerial(self, kodematerial):
        url = self.__url+"?kodematerial="+kodematerial
        payload = {
            "kodematerial":self.__kodematerial,
            "namamaterial":self.__namamaterial,
            "stock":self.__stock
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kodematerial(self,kodematerial):
        url = self.__url+"?kodematerial="+kodematerial
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
