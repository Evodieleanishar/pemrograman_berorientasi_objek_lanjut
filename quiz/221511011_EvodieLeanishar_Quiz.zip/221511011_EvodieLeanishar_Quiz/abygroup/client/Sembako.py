import requests
import json
class Sembako:
    def __init__(self):
        self.__id=None
        self.__kodebarang = None
        self.__namabarang = None
        self.__stock = None
        self.__url = "http://f0834912.xsph.ru/abygroup/sembako/sembako_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kodebarang(self):
        return self.__kodebarang
        
    @kodebarang.setter
    def kodebarang(self, value):
        self.__kodebarang = value
    @property
    def namabarang(self):
        return self.__namabarang
        
    @namabarang.setter
    def namabarang(self, value):
        self.__namabarang = value
    @property
    def stock(self):
        return self.__stock
        
    @stock.setter
    def stock(self, value):
        self.__stock = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kodebarang(self, kodebarang):
        url = self.__url+"?kodebarang="+kodebarang
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['idbarang']
            self.__kodebarang = item['kodebarang']
            self.__namabarang = item['namabarang']
            self.__stock = item['stock']
        return data
    def simpan(self):
        payload = {
            "kodebarang":self.__kodebarang,
            "namabarang":self.__namabarang,
            "stock":self.__stock
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kodebarang(self, kodebarang):
        url = self.__url+"?kodebarang="+kodebarang
        payload = {
            "kodebarang":self.__kodebarang,
            "namabarang":self.__namabarang,
            "stock":self.__stock
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kodebarang(self,kodebarang):
        url = self.__url+"?kodebarang="+kodebarang
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
