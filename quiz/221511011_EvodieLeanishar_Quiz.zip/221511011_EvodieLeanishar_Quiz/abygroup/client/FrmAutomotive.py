import tkinter as tk
import json
from tkinter import Frame,Label,Entry,Button,Radiobutton,ttk,VERTICAL,YES,BOTH,END,Tk,W,StringVar,messagebox
from Automotive import *
class FrmAutomotive:
    
    def __init__(self, parent, title):
        self.parent = parent       
        self.parent.geometry("450x450")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()
        
    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text='KODESPAREPART:').grid(row=0, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='NAMASPAREPART:').grid(row=1, column=0,
            sticky=W, padx=5, pady=5)
        Label(mainFrame, text='STOCK:').grid(row=2, column=0,
            sticky=W, padx=5, pady=5)
        # Textbox
        self.txtKodesparepart = Entry(mainFrame) 
        self.txtKodesparepart.grid(row=0, column=1, padx=5, pady=5)
        self.txtKodesparepart.bind("<Return>",self.onCari) # menambahkan event Enter key
        # Textbox
        self.txtNamasparepart = Entry(mainFrame) 
        self.txtNamasparepart.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtStock = Entry(mainFrame) 
        self.txtStock.grid(row=2, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(mainFrame, text='Simpan', command=self.onSimpan, width=10)
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text='Clear', command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text='Hapus', command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ('idsparepart','kodesparepart','namasparepart','stock')
        self.tree = ttk.Treeview(mainFrame, columns=columns, show='headings')
        # define headings
        self.tree.heading('idsparepart', text='ID')
        self.tree.column('idsparepart', width="50")
        self.tree.heading('kodesparepart', text='KOD')
        self.tree.column('kodesparepart', width="50")
        self.tree.heading('namasparepart', text='NAMA')
        self.tree.column('namasparepart', width="150")
        self.tree.heading('stock', text='STOCK')
        self.tree.column('stock', width="70")
        # set tree position
        self.tree.place(x=0, y=200)
        
    def onClear(self, event=None):
        self.txtKodesparepart.delete(0,END)
        self.txtKodesparepart.insert(END,"")
        self.txtNamasparepart.delete(0,END)
        self.txtNamasparepart.insert(END,"")
        self.txtStock.delete(0,END)
        self.txtStock.insert(END,"")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False
        
    def onReload(self, event=None):
        # get data automotive
        obj = Automotive()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        for i, d in enumerate(parsed_data):
            self.tree.insert("", i, text="Item {}".format(i), values=(d["idsparepart"],d["kodesparepart"],d["namasparepart"],d["stock"]))
    def onCari(self, event=None):
        kodesparepart = self.txtKodesparepart.get()
        obj = Automotive()
        a = obj.get_by_kodesparepart(kodesparepart)
        if(len(a)>0):
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")
    def TampilkanData(self, event=None):
        kodesparepart = self.txtKodesparepart.get()
        obj = Automotive()
        res = obj.get_by_kodesparepart(kodesparepart)
        self.txtKodesparepart.delete(0,END)
        self.txtKodesparepart.insert(END,obj.kodesparepart)
        self.txtNamasparepart.delete(0,END)
        self.txtNamasparepart.insert(END,obj.namasparepart)
        self.txtStock.delete(0,END)
        self.txtStock.insert(END,obj.stock)
        self.btnSimpan.config(text="Update")
                 
    def onSimpan(self, event=None):
        # get the data from input
        kodesparepart = self.txtKodesparepart.get()
        namasparepart = self.txtNamasparepart.get()
        stock = self.txtStock.get()
        # create new Object
        obj = Automotive()
        obj.kodesparepart = kodesparepart
        obj.namasparepart = namasparepart
        obj.stock = stock
        if(self.ditemukan==False):
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_kodesparepart(kodesparepart)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        #clear the form input
        self.onClear()
    def onDelete(self, event=None):
        kodesparepart = self.txtKodesparepart.get()
        obj = Automotive()
        obj.kodesparepart = kodesparepart
        if(self.ditemukan==True):
            res = obj.delete_by_kodesparepart(kodesparepart)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")
            
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        
        # display json data into messagebox
        messagebox.showinfo("showinfo", status+', '+msg)
        
        self.onClear()
            
    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()
if __name__ == '__main__':
    root2 = tk.Tk()
    aplikasi = FrmAutomotive(root2, "Aplikasi Data Automotive")
    root2.mainloop()
