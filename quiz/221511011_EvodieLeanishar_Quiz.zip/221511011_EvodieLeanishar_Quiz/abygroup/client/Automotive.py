import requests
import json
class Automotive:
    def __init__(self):
        self.__id=None
        self.__kodesparepart = None
        self.__namasparepart = None
        self.__stock = None
        self.__url = "http://f0834912.xsph.ru/abygroup/sparepart/automotive_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kodesparepart(self):
        return self.__kodesparepart
        
    @kodesparepart.setter
    def kodesparepart(self, value):
        self.__kodesparepart = value
    @property
    def namasparepart(self):
        return self.__namasparepart
        
    @namasparepart.setter
    def namasparepart(self, value):
        self.__namasparepart = value
    @property
    def stock(self):
        return self.__stock
        
    @stock.setter
    def stock(self, value):
        self.__stock = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kodesparepart(self, kodesparepart):
        url = self.__url+"?kodesparepart="+kodesparepart
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['idsparepart']
            self.__kodesparepart = item['kodesparepart']
            self.__namasparepart = item['namasparepart']
            self.__stock = item['stock']
        return data
    def simpan(self):
        payload = {
            "kodesparepart":self.__kodesparepart,
            "namasparepart":self.__namasparepart,
            "stock":self.__stock
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kodesparepart(self, kodesparepart):
        url = self.__url+"?kodesparepart="+kodesparepart
        payload = {
            "kodesparepart":self.__kodesparepart,
            "namasparepart":self.__namasparepart,
            "stock":self.__stock
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kodesparepart(self,kodesparepart):
        url = self.__url+"?kodesparepart="+kodesparepart
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
