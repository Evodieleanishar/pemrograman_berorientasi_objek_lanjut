import requests
import json
class Buku:
    def __init__(self):
        self.__id=None
        self.__kodebuku = None
        self.__namabuku = None
        self.__status = None
        self.__penulis = None
        self.__url = "http://localhost/perpusclient/appbuku/buku_api.php"
                    
    @property
    def id(self):
        return self.__id
    @property
    def kodebuku(self):
        return self.__kodebuku
        
    @kodebuku.setter
    def kodebuku(self, value):
        self.__kodebuku = value
    @property
    def namabuku(self):
        return self.__namabuku
        
    @namabuku.setter
    def namabuku(self, value):
        self.__namabuku = value
    @property
    def status(self):
        return self.__status
        
    @status.setter
    def status(self, value):
        self.__status = value
    @property
    def penulis(self):
        return self.__penulis
        
    @penulis.setter
    def penulis(self, value):
        self.__penulis = value
    def get_all(self):
        payload ={}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(self.__url, json=payload, headers=headers)
        return response.text
    def get_by_kodebuku(self, kodebuku):
        url = self.__url+"?kodebuku="+kodebuku
        payload = {}
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, json=payload, headers=headers)
        data = json.loads(response.text)
        for item in data:
            self.__id = item['idbuku']
            self.__kodebuku = item['kodebuku']
            self.__namabuku = item['namabuku']
            self.__status = item['status']
            self.__penulis = item['penulis']
        return data
    def simpan(self):
        payload = {
            "kodebuku":self.__kodebuku,
            "namabuku":self.__namabuku,
            "status":self.__status,
            "penulis":self.__penulis
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.post(self.__url, data=payload, headers=headers)
        return response.text
    def update_by_kodebuku(self, kodebuku):
        url = self.__url+"?kodebuku="+kodebuku
        payload = {
            "kodebuku":self.__kodebuku,
            "namabuku":self.__namabuku,
            "status":self.__status,
            "penulis":self.__penulis
            }
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        response = requests.put(url, data=payload, headers=headers)
        return response.text
    def delete_by_kodebuku(self,kodebuku):
        url = self.__url+"?kodebuku="+kodebuku
        headers = {'Content-Type': 'application/json'}
        payload={}
        response = requests.delete(url, json=payload, headers=headers)
        return response.text
